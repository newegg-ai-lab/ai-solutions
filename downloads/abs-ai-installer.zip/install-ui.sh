#!/bin/bash
# ============================================================
#  ABS AI — RTX PRO 6000 Hub, Click-to-Install GUI Wrapper
# ============================================================
# Wraps install.sh with a graphical (zenity) installer experience:
# collects the Telegram bot credentials up front via a form (so
# install.sh never needs to stop and prompt mid-run), then shows
# a progress dialog while install.sh does the real work.
#
# Double-click this from a file manager, or run:
#   chmod +x install-ui.sh && ./install-ui.sh
# from inside the docker-deploy/ directory (same requirement as
# install.sh itself).
# ============================================================

set -euo pipefail

# Resolve relative to this script's own location, not the caller's cwd —
# makes double-clicking from a file manager (which sets cwd unpredictably)
# work the same as running it from a terminal. Assumes install-ui.sh lives
# directly inside docker-deploy/, alongside install.sh and docker-compose.yml.
SCRIPT_DIR="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
DEPLOY_DIR="$SCRIPT_DIR"
INSTALL_SH="$SCRIPT_DIR/install.sh"
LOG_FILE="/tmp/abs-ai-install-$(date +%Y%m%d-%H%M%S 2>/dev/null || echo run).log"

die_gui() {
  zenity --error --title="ABS AI Install" --text="$1" --width=400 2>/dev/null || echo "ERROR: $1" >&2
  exit 1
}

# ------------------------------------------------------------
# 0. Prerequisites for the GUI itself
# ------------------------------------------------------------
if ! command -v zenity >/dev/null 2>&1; then
  echo "zenity not found — installing (needed for the graphical installer)..."
  sudo apt-get update -qq && sudo apt-get install -y -qq zenity \
    || { echo "Could not install zenity. Run install.sh directly from a terminal instead."; exit 1; }
fi

[ -f "$DEPLOY_DIR/docker-compose.yml" ] || die_gui "Run this from inside the docker-deploy/ directory (double-clicking from the wrong folder won't work)."
[ -f "$INSTALL_SH" ] || die_gui "install.sh not found next to install-ui.sh."

zenity --info --title="ABS AI Hub Installer" --width=500 --text="This will set up:\n\n • Qwen3.6-35B-A3B (vLLM inference)\n • Reranker / Embedding / Telegram Bot services\n • Onyx (document search + chat UI)\n\nThis takes a while (large model download) and needs an internet connection.\n\nClick OK to continue." \
  || exit 0

# ------------------------------------------------------------
# 1. Collect Telegram bot credentials up front (avoids install.sh
#    stopping mid-run to prompt on the terminal, which doesn't work
#    well from a double-clicked GUI session)
# ------------------------------------------------------------
TELEGRAM_ENV="$DEPLOY_DIR/telegram-bot/.env"
if [ ! -f "$TELEGRAM_ENV" ]; then
  FORM_RESULT=$(zenity --forms --title="Telegram Bot Setup" --width=500 \
    --text="Get these from Telegram before continuing:\n • Bot token from @BotFather\n • Your numeric user ID from @userinfobot" \
    --add-entry="Telegram Bot Token" \
    --add-entry="Allowed User ID(s) (comma-separated)" \
    --separator="|") || die_gui "Telegram setup was cancelled."

  TG_TOKEN="$(echo "$FORM_RESULT" | cut -d'|' -f1)"
  TG_USERS="$(echo "$FORM_RESULT" | cut -d'|' -f2)"

  [ -n "$TG_TOKEN" ] && [ -n "$TG_USERS" ] || die_gui "Both Telegram fields are required."

  cp "$DEPLOY_DIR/telegram-bot/.env.example" "$TELEGRAM_ENV"
  sed -i "s|^TELEGRAM_BOT_TOKEN=.*|TELEGRAM_BOT_TOKEN=$TG_TOKEN|" "$TELEGRAM_ENV"
  sed -i "s|^ALLOWED_USER_IDS=.*|ALLOWED_USER_IDS=$TG_USERS|" "$TELEGRAM_ENV"
fi

# Optional Hugging Face token (only needed if a model repo is gated;
# the default models used here are public, so this can be skipped).
HF_TOKEN_INPUT=$(zenity --entry --title="Hugging Face Token (optional)" --width=450 \
  --text="Only needed if a model download requires authentication.\nLeave blank to skip." \
  --hide-text) || HF_TOKEN_INPUT=""
[ -n "$HF_TOKEN_INPUT" ] && export HF_TOKEN="$HF_TOKEN_INPUT"

# ------------------------------------------------------------
# 2. Run install.sh with a pulsating progress dialog, translating
#    its own "==>" step markers into the dialog's status text.
# ------------------------------------------------------------
(
  cd "$DEPLOY_DIR"
  bash "$INSTALL_SH" < /dev/null 2>&1 | tee "$LOG_FILE" | while IFS= read -r line; do
    # install.sh's log() prints "\n==> Step X — description\033[0m"
    clean_line="$(echo "$line" | sed -E 's/\x1b\[[0-9;]*m//g')"
    if [[ "$clean_line" == "==>"* ]]; then
      echo "# ${clean_line#==> }"
    fi
  done
) | zenity --progress --title="Installing ABS AI Hub" --width=500 \
    --text="Starting..." --pulsate --auto-close --no-cancel

INSTALL_EXIT=${PIPESTATUS[0]:-0}

# ------------------------------------------------------------
# 3. Final result
# ------------------------------------------------------------
if [ "$INSTALL_EXIT" -eq 0 ] && grep -q "Automated setup is done" "$LOG_FILE"; then
  HOST_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
  zenity --info --title="Install Complete" --width=500 --text="Automated setup is done.\n\nTwo manual steps remain — open http://${HOST_IP:-<this-machine-ip>}:3000/app to finish configuring Onyx.\n\nFull instructions were printed to:\n$LOG_FILE"
else
  zenity --error --title="Install Failed" --width=500 --text="Something went wrong. Check the log for details:\n\n$LOG_FILE"
  exit 1
fi
