#!/bin/bash
# ============================================================
#  ABS AI — RTX PRO 6000 Hub, Fresh Hardware Installer
# ============================================================
# Automates Steps 1-3 of USER_MANUAL_EN.md:
#   1. Deploy Qwen3.6-35B-A3B (vLLM, bare-metal via systemctl)
#   2. Docker-deploy Rerank / Embedding / Mem0 / Telegram Bot
#   3. Deploy Onyx (official docker compose)
#
# Steps 4 and 5 (configuring Onyx through its web UI, then
# copying the resulting token/IDs into the Telegram bot's .env)
# CANNOT be automated — Step 4 doesn't exist until you click
# through the Onyx admin UI yourself. This script prints exact
# instructions for both at the end.
#
# Run this from the docker-deploy/ directory:
#   chmod +x install.sh && ./install.sh
# ============================================================

set -euo pipefail

MODEL_DIR="/models"
VLLM_ENV="/usr/local/vllm_env"
DEPLOY_DIR="$(pwd)"

log()  { echo -e "\n\033[1;36m==> $1\033[0m"; }
warn() { echo -e "\033[1;33m!! $1\033[0m"; }
die()  { echo -e "\033[1;31mERROR: $1\033[0m"; exit 1; }

# ------------------------------------------------------------
# 0. Prerequisite checks
# ------------------------------------------------------------
log "Checking prerequisites"

[ -f "$DEPLOY_DIR/docker-compose.yml" ] || die "Run this script from inside the docker-deploy/ directory."

command -v nvidia-smi >/dev/null 2>&1 || die "nvidia-smi not found. Install the NVIDIA driver first."
nvidia-smi >/dev/null || die "nvidia-smi failed to run — check your GPU driver install."

command -v docker >/dev/null 2>&1 || die "docker not found. Install Docker Engine first."
docker compose version >/dev/null 2>&1 || die "docker compose v2 not found."
command -v python3 >/dev/null 2>&1 || die "python3 not found."
command -v git >/dev/null 2>&1 || die "git not found."

if ! docker run --rm --gpus all nvidia/cuda:12.4.0-base-ubuntu22.04 nvidia-smi >/dev/null 2>&1; then
  warn "Docker can't see the GPU yet. Installing NVIDIA Container Toolkit..."
  curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
  curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
    sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
    sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list >/dev/null
  sudo apt-get update -qq && sudo apt-get install -y -qq nvidia-container-toolkit
  sudo nvidia-ctk runtime configure --runtime=docker
  sudo systemctl restart docker
  docker run --rm --gpus all nvidia/cuda:12.4.0-base-ubuntu22.04 nvidia-smi >/dev/null 2>&1 \
    || die "GPU still not visible to Docker after installing the toolkit."
fi
log "Prerequisites OK"

# ------------------------------------------------------------
# 1. Hugging Face auth — only asked for if a download needs it
# ------------------------------------------------------------
ensure_hf_cli() {
  command -v hf >/dev/null 2>&1 || curl -LsSf https://hf.co/cli/install.sh | bash
  # The hf installer's PATH update lands in ~/.bashrc, which only takes effect
  # in new interactive shells. Export it now so this run benefits too.
  export PATH="$HOME/.local/bin:$PATH"
}

# hf_download <repo> <local-dir>
# Tries an anonymous download first. Only prompts for a token
# if the download actually fails with an auth error (401/403/gated).
hf_download() {
  local repo="$1" dest="$2"
  if hf download "$repo" --local-dir "$dest" 2>/tmp/hf_err.log; then
    return 0
  fi
  if grep -qiE "401|403|gated|access|permission" /tmp/hf_err.log; then
    warn "$repo needs Hugging Face authentication."
    if [ -z "${HF_TOKEN:-}" ]; then
      read -rsp "Enter your Hugging Face access token (huggingface.co/settings/tokens): " HF_TOKEN
      echo
      export HF_TOKEN
    fi
    hf auth login --token "$HF_TOKEN" --add-to-git-credential
    hf download "$repo" --local-dir "$dest"
  else
    cat /tmp/hf_err.log
    die "Failed to download $repo"
  fi
}

ensure_hf_cli
# If the caller already exported HF_TOKEN (e.g. HF_TOKEN=hf_xxx ./install.sh),
# log in up front so every download benefits from it, gated or not.
if [ -n "${HF_TOKEN:-}" ]; then
  hf auth login --token "$HF_TOKEN" --add-to-git-credential >/dev/null 2>&1 || true
fi

# ------------------------------------------------------------
# 2. Step 1 — vLLM bare-metal
# ------------------------------------------------------------
log "Step 1.1 — Creating Python virtual environment"
sudo mkdir -p "$VLLM_ENV" "$MODEL_DIR"
sudo chown "$USER:$USER" "$VLLM_ENV" "$MODEL_DIR"
python3 -m venv "$VLLM_ENV"
# shellcheck disable=SC1091
source "$VLLM_ENV/bin/activate"
pip install -q --upgrade pip

log "Step 1.2 — Downloading Qwen3.6-35B-A3B (large download, this will take a while)"
hf_download "Qwen/Qwen3.6-35B-A3B" "$MODEL_DIR/qwen3.6-35b-a3b"

log "Step 1.3 — Installing inference dependencies"
pip install -q torch torchvision torchaudio \
  --index-url https://download.pytorch.org/whl/cu128 \
  --trusted-host download.pytorch.org
pip install -q vllm==0.18.0 transformers==5.0.0
deactivate

log "Step 1.4 — Writing vLLM startup script"
sudo tee /usr/local/bin/start_vllm.sh > /dev/null <<EOF
#!/bin/bash
cd $VLLM_ENV
source $VLLM_ENV/bin/activate
export VLLM_USE_V1=0
python3 -m vllm.entrypoints.openai.api_server \\
    --model $MODEL_DIR/qwen3.6-35b-a3b \\
    --dtype float16 \\
    --gpu-memory-utilization 0.85 \\
    --max-model-len 150000 \\
    --gdn-prefill-backend triton \\
    --port 8880 \\
    --enable-auto-tool-choice \\
    --tool-call-parser qwen3_coder \\
    --default-chat-template-kwargs '{"enable_thinking": false}' \\
    --served-model-name Qwen-On-Premise
EOF
sudo chmod +x /usr/local/bin/start_vllm.sh

log "Step 1.5 — Installing systemd service"
sudo tee /etc/systemd/system/vllm.service > /dev/null <<'EOF'
[Unit]
Description=vLLM Qwen3.6 35B API Service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
ExecStart=/usr/local/bin/start_vllm.sh
Restart=always
RestartSec=10
TimeoutStartSec=600
LimitNOFILE=65535
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable vllm.service
sudo systemctl start vllm.service

log "Waiting for vLLM to come online (model load can take several minutes)..."
vllm_ready=0
for i in $(seq 1 60); do
  if curl -sf http://localhost:8880/v1/models >/dev/null; then
    vllm_ready=1
    break
  fi
  sleep 10
done
if [ "$vllm_ready" -eq 1 ]; then
  log "vLLM is up on :8880"
else
  warn "vLLM didn't respond after 10 minutes. Check: journalctl -u vllm.service -f"
  warn "Continuing anyway — the Docker services below don't need vLLM to build/start,"
  warn "only to pass their own health checks."
fi

# ------------------------------------------------------------
# 3. Step 2 — Docker services
# ------------------------------------------------------------
log "Step 2.2 — Downloading Rerank / Embedding models"
sudo mkdir -p "$MODEL_DIR/bge-reranker-large" "$MODEL_DIR/multilingual-e5-large"
sudo chown "$USER:$USER" "$MODEL_DIR/bge-reranker-large" "$MODEL_DIR/multilingual-e5-large"
hf_download "BAAI/bge-reranker-large" "$MODEL_DIR/bge-reranker-large"
hf_download "intfloat/multilingual-e5-large" "$MODEL_DIR/multilingual-e5-large"

log "Step 2.3 — Telegram Bot configuration"
cd "$DEPLOY_DIR/telegram-bot"
if [ ! -f .env ]; then
  cp .env.example .env
  echo "You'll need two things from Telegram:"
  echo "  - A bot token from @BotFather"
  echo "  - Your numeric user ID from @userinfobot"
  read -rp "Telegram bot token: " TG_TOKEN
  read -rp "Allowed user ID(s), comma-separated: " TG_USERS
  sed -i "s|^TELEGRAM_BOT_TOKEN=.*|TELEGRAM_BOT_TOKEN=$TG_TOKEN|" .env
  sed -i "s|^ALLOWED_USER_IDS=.*|ALLOWED_USER_IDS=$TG_USERS|" .env
else
  warn ".env already exists in telegram-bot/, leaving it as-is."
fi
cd "$DEPLOY_DIR"

log "Step 2.4 — Building and starting Docker services"
[ -f .env ] || cp .env.example .env
docker compose up -d --build

log "Step 2.5 — Verifying services"
sleep 5
curl -sf http://localhost:8883/health >/dev/null && echo "  bge-reranker-api   OK" || warn "bge-reranker-api not responding yet"
curl -sf http://localhost:8881/health >/dev/null && echo "  text-embedding-api OK" || warn "text-embedding-api not responding yet"
curl -sf http://localhost:8888/health >/dev/null && echo "  qwen3-model-api    OK" || warn "qwen3-model-api not responding yet (also checks vLLM reachability)"

# ------------------------------------------------------------
# 4. Step 3 — Onyx
# ------------------------------------------------------------
log "Step 3 — Deploying Onyx"
if [ ! -d "$DEPLOY_DIR/onyx" ]; then
  git clone https://github.com/onyx-dot-app/onyx.git "$DEPLOY_DIR/onyx"
fi
cd "$DEPLOY_DIR/onyx/deployment/docker_compose"
if [ ! -f .env ]; then
  cp env.template .env
  SECRET=$(openssl rand -hex 32)
  sed -i "s|^USER_AUTH_SECRET=.*|USER_AUTH_SECRET=$SECRET|" .env
  log "Generated a random USER_AUTH_SECRET for Onyx."
else
  warn ".env already exists in onyx/deployment/docker_compose/, leaving it as-is."
fi

# Use the plain docker-compose.yml, not docker-compose.prod.yml or
# docker-compose.prod-no-letsencrypt.yml: this deployment has no public
# domain, and both prod variants configure nginx to require a real or
# self-signed SSL certificate that this setup has no good way to provide.
# docker-compose.yml's nginx runs plain HTTP (DOMAIN=localhost, no cert
# needed) and publishes both :80 and :3000.
docker compose -f docker-compose.yml up -d
cd "$DEPLOY_DIR"

HOST_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
[ -n "$HOST_IP" ] || HOST_IP="<this-machine-ip>"

# ------------------------------------------------------------
# 5. Done — manual steps remain
# ------------------------------------------------------------
cat <<EOF

============================================================
 Automated setup is done. Two manual steps remain because
 they require actions in the Onyx web UI that this script
 cannot perform for you:

 STEP 4 — Configure Onyx
   1. Visit http://$HOST_IP:3000/app and create an admin account
   2. Admin Panel -> API Keys -> New
        -> generate a Service Account Token (starts with on_)
   3. Admin Panel -> LLM Providers -> Add
        API Base URL: http://host.docker.internal:8888/qwen3-model/v1
        Model Name:   Qwen-On-Premise
   4. Admin Panel -> Embedding -> Add Provider
        API Base URL: http://host.docker.internal:8881/v1
        Model Name:   multilingual-e5-large
        Dimensions:   1024
   5. Admin Panel -> Document Sets -> New
        Name it exactly: ABS_AI
   6. Admin Panel -> Assistants (Persona) -> New
        Bind it to the ABS_AI Document Set
        Note the Persona ID (visible in the URL or list page)

 STEP 5 — Finish the Telegram Bot config
   Edit telegram-bot/.env and fill in:
     ONYX_SERVICE_ACCOUNT_TOKEN   (from Step 4.2 above)
     ONYX_PERSONA_ID              (from Step 4.6 above)
     ONYX_DOCUMENT_SET=ABS_AI
   Then run:
     docker compose up -d --build telegram-bot

 Full manual: USER_MANUAL_EN.md
============================================================
EOF
